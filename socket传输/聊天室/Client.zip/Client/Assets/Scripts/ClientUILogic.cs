﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using System;

public class ClientUILogic : MonoBehaviour {

    public Text contentTxt;
    public InputField inputField;
    public Button sendBtn;

    ClientSocket clientSocket;

    // Use this for initialization
    void Start()
    {
        sendBtn.onClick.AddListener(SendMsg);
        clientSocket = new ClientSocket(OnReciveMsg);
    }

    private void OnReciveMsg(string msg)
    {
        if(!string.IsNullOrEmpty(msg))
        {
            contentTxt.text = msg;
        }
    }


    // Update is called once per frame
    void Update () {
        
    }


	private void SendMsg()
	{
        if(!string.IsNullOrEmpty(inputField.text) && clientSocket != null)
        {
            clientSocket.Send(inputField.text);
        }
	}

    private void OnDestroy()
    {
        if(clientSocket != null)
            clientSocket.CloseSocketConnect();
    }
}
