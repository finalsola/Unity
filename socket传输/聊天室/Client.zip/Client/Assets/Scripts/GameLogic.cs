﻿using System.Collections;
using System.Collections.Generic;
using System.Net;
using UnityEngine;

public static class GameLogic {

    public static IPAddress address;
    public static int port;
}
