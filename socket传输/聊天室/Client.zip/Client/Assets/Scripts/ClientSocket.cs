﻿using System.Collections;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Text;
using System.Collections.Generic;
using System;

public class ClientSocket {

    public delegate void ReciveMsgHandler(string msg);
    public ReciveMsgHandler reciveMsg;

    Socket clientSocket;

    IPAddress ip;
    int port;

    byte[] buffer = new byte[1024*1024];

    /// <summary>
    /// 构造函数，传入一个回调方法，当此socket接收到服务器发送的消息之后就会通过此回调通知UI层(ClientUILogic.cs)
    /// </summary>
    /// <param name="handler">Handler.</param>
    public ClientSocket(ReciveMsgHandler handler)
    {
        ip = GameLogic.address;
        port = GameLogic.port;
        reciveMsg = handler;
        clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        clientSocket.Connect(ip, port);

        Thread reciveMessageFromServer = new Thread(ReciveMessageFromServer); //创建一个新的线程专门用来接收服务器发给我们的消息
        reciveMessageFromServer.Start();
    }

    private void ReciveMessageFromServer()
    {
        while (true)
        {
            if (clientSocket == null)
                break;
			int bufferCount = clientSocket.Receive(buffer); //阻塞型接收
			string msg = Encoding.UTF8.GetString(buffer, 0, bufferCount);
			reciveMsg(msg);
        }
    }

    /// <summary>
    /// 通过此方法就可以将UI层中InputFidel中的内容发送给服务器。
    /// </summary>
    /// <returns>The send.</returns>
    /// <param name="msg">Message.</param>
    public void Send(string msg)
    {
        if (clientSocket == null)
            return;
        byte[] msgBuffer = Encoding.UTF8.GetBytes(msg);
        clientSocket.Send(msgBuffer);  //通过clientSocket发送一组byte字节流给服务器。
    }

    /// <summary>
    /// 关闭套接字连接
    /// </summary>
    public void CloseSocketConnect()
    {
        clientSocket.Close();
        clientSocket = null;
    }
}
