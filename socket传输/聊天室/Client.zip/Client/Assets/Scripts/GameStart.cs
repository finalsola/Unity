﻿using System.Collections;
using System.Collections.Generic;
using System.Net;
using UnityEngine.UI;
using UnityEngine;
using UnityEngine.SceneManagement;
using System;

public class GameStart : MonoBehaviour {

    public InputField ipIput;
    public InputField portIput;
    public GameObject warringTxt;
    public Button loginBtn;

    private IPAddress address;
    private int port;

	// Use this for initialization
	void Start () {
        loginBtn.onClick.AddListener(OnClickLoginBtn);
	}

    private void OnClickLoginBtn()
    {
        if(string.IsNullOrEmpty(ipIput.text) || string.IsNullOrEmpty(portIput.text))
        {
            warringTxt.SetActive(true);
        }
        else if(IPAddress.TryParse(ipIput.text, out address))
        {
            port = int.Parse(portIput.text);
            GameLogic.address = address;
            GameLogic.port = port;
            SceneManager.LoadScene(1);
        }
    }

    // Update is called once per frame
    void Update () {
		
	}
}
