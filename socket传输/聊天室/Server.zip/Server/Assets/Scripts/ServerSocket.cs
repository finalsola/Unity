﻿using System.Collections;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Text;
using System.Collections.Generic;
using System;
using UnityEngine;

public class ServerSocket {

    Socket serverSocket;
    string ip = "127.0.0.1";
    int port = 5555;

    byte[] buffer = new byte[1024 * 1024];

    LinkedList<Socket> sockets = new LinkedList<Socket>();

    public ServerSocket()
    {
        serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp); //创建socket对象
        IPEndPoint endPoint = new IPEndPoint(IPAddress.Parse(ip), port); //ip和端口的组合绑定
        serverSocket.Bind(endPoint); //通过这个endpoint对象绑定其中的ip和端口，这个绑定是为了监听我们这个端口上的链接
        serverSocket.Listen(10); //设置监听链接的数量

        Thread acceptConnect = new Thread(AcceptConnect);
        acceptConnect.Start();
    }

    private void AcceptConnect()
    {
        Debug.Log("服务器开启成功，等待客户端链接");
        while (true)
        {
            if (serverSocket == null)
                break;
            Socket clientSocket = serverSocket.Accept(); //阻塞型的监听，如果有客户端链接上来了，就会返回一个对应那个客户端的socket对象，程序向下执行。
            string msg = "链接成功";
            byte[] sendMsg = Encoding.UTF8.GetBytes(msg);
            clientSocket.Send(sendMsg); //返回给刚才链接进来的客户端，告诉他链接成功
            sockets.AddLast(clientSocket);

            Thread reciveClientMsg = new Thread(ReciveClientMsg);  //开启一个线程，专门用来接收刚才那个客户端发送给我们的数据。
            reciveClientMsg.Start(clientSocket);
        }
    }

    private void ReciveClientMsg(object socket)
    {
        Debug.Log("有一个客户端已链接");
        Socket clientSocket = socket as Socket; //线程是可以传递参数的，但是只能是opbject类型，需要将这个对象转换成为Socket才可以使用
        while (true)
        {
            if (clientSocket == null || !clientSocket.Connected || serverSocket == null) //判断当前和客户端的链接不为null或者没有断开链接，才可以继续接收数据
            {
                sockets.Remove(clientSocket);
                break;
            }
            int bufferCount = clientSocket.Receive(buffer); //通过Socket的Recive方法接收客户端发送的数据，返回一个真实接收到的字节流数量
            byte[] _buffer = new byte[bufferCount];
            Array.Copy(buffer, _buffer, bufferCount); //通过集合复制的过程将真实的数据拷贝到新数组中，send回去
            //clientSocket.Send(_buffer);
            foreach (var item in sockets)
            {
                if (item == null || item.Connected == false)
                    continue;
                item.Send(_buffer);
            }
        }
    }

    public void CloseServer()
    {
		sockets.Clear();
        serverSocket.Close();
        serverSocket = null;
        Debug.Log("服务器已关闭");
    }
}
