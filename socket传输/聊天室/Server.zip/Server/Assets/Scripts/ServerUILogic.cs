﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using System;

public class ServerUILogic : MonoBehaviour {

    public Button openServerBtn;
    public Button closeServerBtn;

    private ServerSocket serverSocket;

	// Use this for initialization
	void Start () {
        openServerBtn.onClick.AddListener(OpenServer);
        closeServerBtn.onClick.AddListener(CloseServer);
	}

    private void CloseServer()
    {
        openServerBtn.gameObject.SetActive(true);
        closeServerBtn.gameObject.SetActive(false);

        serverSocket.CloseServer();
        serverSocket = null;
    }

    private void OpenServer()
    {
        openServerBtn.gameObject.SetActive(false);
        closeServerBtn.gameObject.SetActive(true);

        if (serverSocket != null)
            serverSocket.CloseServer();
        
        serverSocket = new ServerSocket();
    }

    // Update is called once per frame
    void Update () {
		
	}

    private void OnDestroy()
    {
        if (serverSocket != null)
        {       
            serverSocket.CloseServer();
            serverSocket = null;
        }
    }
}
